package com.example.githubusersubmission

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubusersubmission.adapter.FollowersAdapter
import com.example.githubusersubmission.adapter.FollowingAdapter
import com.example.githubusersubmission.viewmodel.FollowersViewModel
import com.example.githubusersubmission.viewmodel.FollowingViewModel
import kotlinx.android.synthetic.main.fragment_follows.*

class FollowFragment : Fragment() {
    private lateinit var followersAdapter: FollowersAdapter
    private lateinit var followingAdapter: FollowingAdapter

    private lateinit var followersViewModel: FollowersViewModel
    private lateinit var followingViewModel: FollowingViewModel

    companion object {
        private const val ARG_USERNAME = "username"
        private const val ARG_SECTION_NUMBER = "section_number"

        fun newInstance(index: Int, username: String?): FollowFragment {
            val fragment = FollowFragment()
            val bundle = Bundle()
            bundle.putString(ARG_USERNAME, username)
            bundle.putInt(ARG_SECTION_NUMBER, index)

            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_follows, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (arguments != null) {
            val index = arguments?.getInt(ARG_SECTION_NUMBER, 0) as Int
            when (index) {
                1 -> {
                    followersAdapter = FollowersAdapter()

                    rv_followers.setHasFixedSize(true)
                    rv_followers.layoutManager = LinearLayoutManager(activity)

                    rv_followers.adapter = followersAdapter

                    val username = arguments?.getString(ARG_USERNAME)
                    followersViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(FollowersViewModel::class.java)
                    followersViewModel.setListFollowers(username.toString())
                    followersViewModel.getUsers().observe(viewLifecycleOwner, { userModel ->
                        if (userModel != null) {
                            followersAdapter.setData(userModel)
                        }
                    })
                }
                2 -> {
                    followingAdapter = FollowingAdapter()

                    rv_followers.setHasFixedSize(true)
                    rv_followers.layoutManager = LinearLayoutManager(activity)

                    rv_followers.adapter = followingAdapter

                    val username = arguments?.getString(ARG_USERNAME)
                    followingViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(FollowingViewModel::class.java)
                    followingViewModel.setListFollowing(username.toString())
                    followingViewModel.getUsers().observe(viewLifecycleOwner, { userModel ->
                        if (userModel != null) {
                            followingAdapter.setData(userModel)
                        }
                    })
                }
            }
        }
    }
}